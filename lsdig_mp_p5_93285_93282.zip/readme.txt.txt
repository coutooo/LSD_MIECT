Miniprojeto LSD 2017/2018
Temporizador com pause/start reset e freeze.

Usamos o clock50 da fpga, para obter o sinal necess�rio utilizamos o divisor de frequencia.
Ligamos este sinal � entrada clock do contador, contador este que vai decrementando o "5999".
Usamos ainda um conversor de bin�rio para BCD.
O contador possui um pause, um start, um reset e um freeze/unfreeze.
Usamos o display de 7 segmentos(Bin7SegDecoder).
Para implementar o freeze, usamos ainda um register.

KEY[1] -> start/stop
KEY[0] -> se estiver em start d� freeze e se clicarmos outra vez unfreeze
	  se estiver em stop clicando duas vezes da reset
LEDG[8]
HEX[0]
HEX[1]
HEX[2]
HEX[3]


Docente: Iouliia Skliarova

MIECT 
Autores: Manuel Couto nmec -> 93285    50%
	 Jo�o Oliveira nmec ->93282       50%
